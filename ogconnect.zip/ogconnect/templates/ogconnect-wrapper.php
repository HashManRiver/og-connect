<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/********************************************************************************************************
*
*
*	[OGConnect - Main Wrapper Template]
*
*	you will probably want to make a copy of the archive.php, page.php or index.php
*	 file in your theme folder, rename it to ogconnect-wrapper.php and copy the bit marked below into that 
*	 copied page, REPLACING the WHOLE loop . ie the bit that will look something like :
*	------------- 	
*	while ( have_posts() ) : the_post(); 
*		
*		//stuff inside the loop
*		
*	endwhile; // end of the loop.
*	------------------
*	 to make the thing play nice with your theme......
*
********************************************************************************************************/
get_header(); 

?>
	<div id="primary" class="site-content">
		<div id="content" role="main">
<?php 
/******************************************************************************
*
*	[copy from here .....]
*
*****************************************************************************/		

		/****************************************************************
		if the loop template has been copied to the theme folder we get the template part
		otherwise, include from plugin template directory
		if using a ogconnect subdirectory, change array ('ogconnect-loop.php') to array ('ogconnect/ogconnect-loop.php' )
		****************************************************************/
		if ($template_file = locate_template( array ('ogconnect-loop.php' ))){/*use ogconnect-loop-responsive.php instead if using the responsive css/layout in ogconnect->settings*/
			include_once($template_file);
		}else{
			include_once(''.OGCONNECT_PATH.'templates/ogconnect-loop.php');/*use ogconnect-loop-responsive.php instead if using the responsive css/layout in ogconnect->settings*/			
		}

/******************************************************************************
*
*	[...........copy to here]
*	
*****************************************************************************/
?>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>