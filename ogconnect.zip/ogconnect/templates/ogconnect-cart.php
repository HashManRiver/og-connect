<?php
if ( ! defined( 'ABSPATH' ) ) exit;/*Exit if accessed directly*/
 /*
 	OGConnect Shopping Cart
 */
 /**********************************************************************************************************
 	to keep things consistent when adding an item via ajax
 	we build the cart contents here to insert below when
 	loading page, or returning when getting via ajax
 	depending on set currency position in layout currency_left or currency_right will be empty 
 ***********************************************************************************************************/
$cartContents='';
if(isset($cart['innercartinfo'])){
	$cartContents='<p>'.$cart['innercartinfo'].'</p>';
}else{
	$cartContents='<ul class="ogconnect-cart-contents">';
	/**allow item filtering. ADDED 2.8.9.4*****/
	$cart['items'] = apply_filters('ogconnect_cart_filter_items', $cart['items'], 'cart');
	foreach($cart['items'] as $k=>$item){
		/***allow action per item - probably to use in conjunction with filter above.  ADDED 2.8.9.4****/
		$cartContents = apply_filters('ogconnect_cart_item', $item, $cartContents);	
		
		$cartContents.='<li id="ogconnect-cart-item-'.$k.'" class="ogconnect-cart-item">';
		/**filter if required**/
		$cartContents = apply_filters('ogconnect_cart_item_start', $cartContents, $item);

		/********CHANGES IN 2.5, *****alloow increase/decrease changed 2.5*************/
		if(isset($cart['increase_decrease'])){
			$cartContents.="<input type='text' size=3 class='ogconnect-cart-incr' name='ogconnect-cart-incr' value='".$item['count']."'>";
			$cartContents.='<span id="ogconnect-cart-'.$k.'" class="ogconnect-cart-increment" title="">&#10003;</span>';
		}else{
			$cartContents.='<span id="ogconnect-cart-'.$k.'" class="ogconnect-remove-from-cart" title="'.$txt['remove_from_cart']['lbl'].'">x</span>';
		}
		
		$cartContents = apply_filters('ogconnect_cart_item_after_edit', $cartContents, $item);
		
		/********CHANGES IN 2.9: we do not need to display this really if we are already using text boxes.**/
		if(isset($cart['increase_decrease'])){
			$cartContents.='<span class="ogconnect-cart-item-name">'.$item['name'].'</span>';
		}else{
			$cartContents.='<span class="ogconnect-cart-item-name">'.$item['count'].'x '.$item['name'].'</span>';	
		}
		
		
		/***************************************************************/

		if($item['size']!=''){
		$cartContents.='<span class="ogconnect-cart-item-size">'.$item['size'].'</span> ';
		}
		/*****************************************
			CHANGES IN 2.5,
			changed	ogconnect_output_format_price($item['pricetotal'],$options['layout']['hide_decimals']);
			to just $item['pricetotal']
		***********************************/
		/**filter if required**/
		$cartContents = apply_filters('ogconnect_cart_item_before_item_price', $cartContents, $item);	

		$cartContents.='<span class="ogconnect-cart-item-price">'.$cart['currency_left'].''.$item['pricetotal'].''.$cart['currency_right'].'</span>';
		/**filter if required**/
		$cartContents = apply_filters('ogconnect_cart_item_after_item_price', $cartContents, $item);	

		if(is_array($item['additionalinfo']) && count($item['additionalinfo'])>0){
			
			$cartContents.='<div class="ogconnect-item-additional-info">';
			/**filter if required**/
			$cartContents = apply_filters('ogconnect_cart_item_inside_additional_info_top', $cartContents, $item);
			
				$cartContents.='<div class="ogconnect-item-additional-info-icon"></div>';
			
				$cartContents.='<div class="ogconnect-item-additional-info-pad">';
				foreach($item['additionalinfo'] as $addItem){
					$cartContents.='<span class="ogconnect-item-additional-info-content">'.$addItem.'</span>';
				}
				$cartContents.='</div>';
				
			/**filter if required**/
			$cartContents = apply_filters('ogconnect_cart_item_inside_additional_info_bottom', $cartContents, $item);			
			$cartContents.='</div>';
		}
		
		/**filter if required**/
		$cartContents = apply_filters('ogconnect_cart_item_end', $cartContents, $item);			
		$cartContents.='</li>';
	}
	$cartContents.='</ul>';
}
/******************************************************
	[request was made via ajax, when adding item, so only return item html]
******************************************************/
if(isset($request) && $request=='ajax'){
	echo $cartContents;
return;
}
?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_start');
?>
<?php if(isset($openingTimes)){ ?>
	<div class="ogconnect-opening-hours"<?php if(isset($cartStyle['width'])){echo $cartStyle['width'];}?>><?php echo $openingTimes ?></div>
<?php } ?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_before_cart');
?>
<div class="ogconnect-cart <?php echo $stickycart; ?>"<?php if(isset($cartStyle['cart'])){echo $cartStyle['cart'];}?>>
	<?php if($cart['shopopen']==1){ /*make sure that we are open*/ ?>
	<input type='hidden' class='ogconnect-open' name='ogconnect-open' />
	<?php } ?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_before_order');
?>
	<div class="ogconnect-order">
	<?php echo $cartContents ?>
	</div>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_before_info');
?>
	<div class="ogconnect-cart-info">
			<div class="ogconnect-cart-nocheckout"><?php echo $cart['nocheckout'] ?></div>
			<span class="ogconnect-cart-total-items">
				<span class="ogconnect-cart-total-items-label">
					<?php if(count($cart['items'])>0){?>
						<?php echo $cart['order_value']['total_price_items']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-total-items-value ogconnect-cart-info-price">
					<?php if(count($cart['items'])>0){?>
						<?php echo $cart['currency_left'].''.$cart['order_value']['total_price_items']['val'].''.$cart['currency_right']; ?>
					<?php } ?>
				</span>
			</span>

			<span class="ogconnect-cart-discount">
				<span class="ogconnect-cart-discount-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['discount']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-discount-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0 && $cart['order_value']['discount']['val']>0){?>
					<?php echo '<span class="ogconnect-minus"></span>'.$cart['currency_left'].''.$cart['order_value']['discount']['val'].''.$cart['currency_right']; ?>
					<?php } ?>
				</span>
			</span>

			<?php if(isset($cart['tax_enabled']) && $cart['tax_applied']=='items_only'){ /*SUM SALES TAX - ITEMS ONLY: CONDITIONAL ADDED/CHANGED IN VERSION 2.0 and 2.5*/ ?>
			<span class="ogconnect-cart-tax ogconnect-car-tax-itemsonly">
				<span class="ogconnect-cart-tax-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['item_tax']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-tax-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['currency_left'].''.$cart['order_value']['item_tax']['val'].''.$cart['currency_right']; ?>
					<?php } ?>
				</span>
			</span>
			<?php } ?>

			<?php if(!isset($cart['self_pickup_enabled']) || $cart['selfPickup']==0){ /*NOT SELFPICKUP : CONDITIONAL ADDED/CHANGED IN Version 1.4.1*/ ?>
			<span class="ogconnect-cart-delivery">
				<span class="ogconnect-cart-delivery-charges-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['delivery_charges']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-delivery-charges-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php 
						if($cart['order_value']['delivery_charges']['val']!=''){echo $cart['currency_left'].''.$cart['order_value']['delivery_charges']['val'].''.$cart['currency_right']; ?>
					<?php }} ?>
				</span>
			</span>
			<?php } ?>

			<?php if(isset($cart['tax_enabled']) && $cart['tax_applied']=='items_and_shipping'){ /*SUM TAX - applied to items AND shipping: CONDITIONAL ADDED/CHANGED IN VERSION 2.0 and 2.5*/ ?>
			<span class="ogconnect-cart-tax ogconnect-car-tax-itemsshipping">
				<span class="ogconnect-cart-tax-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['item_tax']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-tax-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['currency_left'].''.$cart['order_value']['item_tax']['val'].''.$cart['currency_right']; ?>
					<?php } ?>
				</span>
			</span>
			<?php } ?>
	
			<?php if(isset($cart['tax_enabled']) && $cart['tax_applied']=='taxes_included'){ /*SUMMARY OF ALL TAXES IF INCLUDED IN SET PRICES ADDED 2.8.9.3*/ ?>
			<span class="ogconnect-cart-tax-included">
				<span class="ogconnect-cart-tax-included-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['taxes_included']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-tax-included-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['currency_left'].''.$cart['order_value']['taxes_included']['val'].''.$cart['currency_right']; ?>
					<?php } ?>
				</span>
			</span>
			<?php } ?>

			<?php if(isset($cart['tips']) && $cart['tips']>0){/*tips NEW 2.8.4*/?>
			<span class="ogconnect-order-tips">
				<span class="ogconnect-order-tips-label">
					<?php echo $cart['tips']['lbl'] ?>
				</span>
				<span class="ogconnect-order-tips-value ogconnect-cart-info-price">
					<?php echo $cart['currency_left'].''.$cart['tips']['val'].''.$cart['currency_right']; ?>
				</span>
			</span>
			<?php } ?>
		<?php
			/**added 2.11.4*/
			do_action('ogconnect_cart_before_totals',$cart);
		?>
			<span class="ogconnect-cart-total">
				<span class="ogconnect-cart-total-label">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['order_value']['total']['lbl'] ?>
					<?php } ?>
				</span>
				<span class="ogconnect-cart-total-value ogconnect-cart-info-price">
					<?php if($cart['nocheckout']=='' && count($cart['items'])>0){?>
					<?php echo $cart['currency_left'].''.$cart['order_value']['total']['val'].''.$cart['currency_right'] ?>
					<?php } ?>
				</span>
			</span>
		<?php
			/**added 2.11.4*/
			do_action('ogconnect_cart_after_totals',$cart);
		?>			
			<?php if($cart['nocheckout']=='' && isset($cart['self_pickup_enabled']) && $cart['selfPickup']==1	){ /*SELFPICKUP ENABLED AND SELECTED : ADDED/CHANGED IN V1.4.1**/ ?>
			<span id="ogconnect-cart-self-pickup">
				<?php echo ($cart['order_self_pickup_cart']) ?>
			</span>
			<?php } ?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_before_cartbutton');
?>
		<div class="ogconnect-cart-button"><?php echo $cart['button'] ?></div>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_after_cartbutton');
?>
	</div>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_after_info');
?>
</div>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_after_cart');
?>
<?php if(isset($cart['self_pickup_enabled']) && isset($cart['self_pickup_cart'])){ /*ALLOW SELF PICKUP AND DISPLAY IN CART: ADDED/CHANGED IN V1.4.1**/ ?>
	<div class="ogconnect-order-pickup-choice">
	<label><input type='checkbox' id='<?php echo $cart['selfPickupId'] ?>' name='ogconnect-order-pickup' value='1' <?php checked($cart['selfPickup'],1,true) ?> /><?php echo $cart['order_self_pickup'] ?></label>
	</div>
<?php } ?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_before_orderinfo');
?>
<?php if(isset($orderinfo)){ ?>
	<ul id="ogconnect-orders-info" <?php if(isset($cartStyle['width'])){echo $cartStyle['width'];}?>>
		<?php if(isset($cart['pricing_discounts'])){foreach($cart['pricing_discounts'] as $discounts){?>
			<li><?php echo $discounts ?></li>
		<?php }}?>
		<?php if(isset($cart['pricing_delivery'])){?>
			<li><?php echo $cart['pricing_delivery'] ?></li>
			<?php if(isset($cart['pricing_delivery_per_item_free'])){?>
			<li><?php echo $cart['pricing_delivery_per_item_free'] ?></li>
			<?php }?>
		<?php }?>
	</ul>
<?php } ?>
<?php
	/*ADDED IN VERSION 2.7.3*/
	do_action('ogconnect_cart_end');
?>