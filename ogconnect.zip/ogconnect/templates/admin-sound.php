<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/********************************************************************************************************
*
*
*	[OGConnect - admin soundTemplate]
*
*	you will probably have to put this in the functions.php somewhere...
*	 to make the thing play nice with your theme......
*
********************************************************************************************************/

/*************************************************************************
        play sound on new order in order history.
        repeats every 5 sec (60000 ms) until there's no
        new order anymore (just change the status)....
        set timeout (5000) to whatever timeinterval is required
        set soundfile (notifySound)  to whatever sound is supposed to be played
        if using IE, use an mp3 file instead of .wav
    ***************************************************************************/
    add_action('admin_footer', 'ogconnect_notify_new_orders');
    function ogconnect_notify_new_orders(){
        global $current_screen;
        if(isset($current_screen) && $current_screen->id=='ogconnect_page_ogconnect-order-history'){
       
        echo"<script type='text/javascript'>
            /* <![CDATA[ */
            jQuery(document).ready(function($){
                    var notifySound = '".get_template_directory_uri()."/notify.wav';
                    var notifyNewOrders = new Audio(notifySound);
                    var notifyNewOrdersInterval=setInterval(function(){
                    if($('.ogconnect-ord-status-new').length>0){       
                        notifyNewOrders.play();
                    }},(60000));
           
            });
            /* ]]> */
        </script>";
        }
    }