<?php
if ( ! defined( 'ABSPATH' ) ) exit;/*Exit if accessed directly*/
/***********************************************************************************************************************************************************************************************
*
*	OGConnect Confirmation Page before order is going to be sent to gateway 
*
*	ONLY USED IF ENABLED IN ORDER FORM SETTINGS
*
***********************************************************************************************************************************************************************************************/
?>
<?php 
/**************************************************************************************************************
*
*
*		[additional form fields for accepting AGB and what not]
*		$confirmationelements = enabled fields
*
**************************************************************************************************************/ 
?>
<?php if(count($cart['items'])>0 && count($confirmationelements)>0){/*make sure there are elements to display and stuff to order***/?>
	<fieldset id="ogconnect-confirm-legal">
		<legend><?php echo $txt['legend_legal'] ?></legend>
		<?php foreach($confirmationelements as $elmKey=>$elm){?>
				<label for="<?php echo $elm['key'] ?>">
					<?php if($elm['type']=='checkbox'){ ?>
						<span id="ogconnect-confirm-elm-<?php echo $elm['key'] ?>" class="ogconnect-confirm-elm">
							<input id="<?php echo $elm['key'] ?>" name="<?php echo $elm['key'] ?>" type="checkbox" value="1" <?php echo !empty($elm['required'])?'required':'' ?>/>
						</span>
					<?php } ?>
					<span id="ogconnect-confirm-lbl-<?php echo $elm['key'] ?>" class="ogconnect-confirm-lbl<?php echo !empty($elm['required']) && $elm['type']!='link' ? ' ogconnect-confirm-label-required':'' ?>">
						<?php echo $elm['lbl'] ?>
					</span>
				</label>
		<?php } ?>
	</fieldset>
<?php } ?>
<?php 
/**************************************************************************************************************
*
*
*		[user information]
*		$formelements = enabled fields
*		let's add submitted user details as hidden fields again
*
**************************************************************************************************************/ 
?>
<?php if(count($cart['items'])>0){/*make sure there's stuff to order***/?>
	<fieldset id="ogconnect-confirm-user">
		<legend><?php echo $txt['legend_personal'] ?> <a href="<?php echo $orderpagelink ?>" class="ogconnect-confirm-dochange"><?php echo $txt['change_user_details'] ?></a></legend>
		<?php foreach($formelements as $elmKey=>$elm){?>
			<div>
				<label for="<?php echo $elm['key'] ?>"><?php echo $elm['lbl'] ?></label>
				<span><?php echo $elm['userVal'] ?></span>
				<input name="<?php echo $elm['key'] ?>" type="hidden" value="<?php echo $elm['userVal'] ?>" />
			</div>
		<?php } ?>	
	</fieldset>
<?php } ?>
<?php 
/**************************************************************************************************************
*
*
*		[payment method information]
*
*
**************************************************************************************************************/ 
?>
<?php if(count($cart['items'])>0){/*make sure there's stuff to order***/?>
	<fieldset id="ogconnect-confirm-payment-method">
		<legend><?php echo $txt['legend_payment_method'] ?> <a href="<?php echo $orderpagelink ?>" class="ogconnect-confirm-dochange"><?php echo $txt['change_user_details'] ?></a></legend>
		<div>
			<label><?php echo $txt['payment_method'] ?></label>
			<span>
				<?php echo $gatewayLabel ?>
			</span>
			<?php foreach($paymentmethod as $elmKey=>$elm){/*in case a filter wants to add things*/?>
			<div>
				<label for="<?php echo $elm['key'] ?>"><?php echo $elm['lbl'] ?></label>
				<span><?php echo $elm['userVal'] ?></span>
				<input name="<?php echo $elm['key'] ?>" type="hidden" value="<?php echo $elm['userVal'] ?>" />
			</div>
			<?php } ?>			
		</div>	
	</fieldset>
<?php } ?>
<?php 
/**************************************************************************************************************
*
*
*		[cart information and summary]
*
*
**************************************************************************************************************/ 
?>		
<?php 
	/**************************************************************************************************************
		[cart info]
	**************************************************************************************************************/ 
?>
	<fieldset id="ogconnect-confirm-cart-contents">
		<legend><?php echo $txt['legend_order_details'] ?> <a href="<?php echo $amendorderlink ?>" class="ogconnect-confirm-dochange"><?php echo $txt['change_order_details'] ?></a></legend>		

<?php 
	/**************************************************************************************************************
		[self pickup selected]
	**************************************************************************************************************/ 
?>			
			<?php if(isset($cart['self_pickup_enabled']) &&  $cart['selfPickup']==1 && $txt['order_page_self_pickup']!=''){ /*self pickup conditional-> no delivery charges **/ ?>
				<div id="ogconnect-self-pickup"><?php echo $txt['order_page_self_pickup'] ?></div>
			<?php } ?>

			<?php if(isset($cart['self_pickup_enabled']) &&  $cart['selfPickup']==2 && $txt['order_page_no_delivery']!=''){ /*no delivery offered **/  ?>
				<div id="ogconnect-self-pickup"><?php echo $txt['order_page_no_delivery'] ?></div>
			<?php } ?>	

<?php 
	/**************************************************************************************************************
		[cart itemised]
	**************************************************************************************************************/ 
?>
		<?php if(count($cart['items'])>0){/*make sure there's stuff to order***/?>
			<table id="ogconnect-confirm-itemmised-details">
				<tr class="ogconnect-confirm-itemised-th">
					<?php
					/**added 2.10.2*/
					/**construct the markup display of header**/
					$headerMarkup=array();
					$headerMarkup['item']='<th class="ogconnect-confirm-item-th">'.$txt['header_itemised_article'].'</th>';
					$headerMarkup['price']='<th class="ogconnect-confirm-item-price-th">'.$txt['header_itemised_price_single'].'</th>';
					$headerMarkup['quantity']='<th class="ogconnect-confirm-item-quantity-th">'.$txt['header_itemised_quantity'].'</th>';
					$headerMarkup['total']='<th class="ogconnect-confirm-item-price-total-th">'.$txt['header_itemised_price'].'</th>';
					/**filter if necessary*/
					$headerMarkup = apply_filters('ogconnect_filter_confirmation_item_header_markup', $headerMarkup, $txt);	
					/**output markup**/
					echo''.implode("",$headerMarkup).'';				
					?>
				</tr>
				
				<?php foreach($cart['items'] as $itemKey=>$item){ ?>
				<tr class="ogconnect-confirm-itemised">
				<?php
					/**added 2.10.2*/
					/**construct the markup display of this item**/
					$itemMarkup=array();
					$itemMarkup['tdopen']='<td class="ogconnect-confirm-item">';
					$itemMarkup['name']=''.$item['name'].'';
					$itemMarkup['size']=' '.$item['size'].'';
					$itemMarkup['additionalinfo']='';
					if(is_array($item['additionalinfo']) && count($item['additionalinfo'])>0){
						$itemMarkup['additionalinfo'].='<div class="ogconnect-item-additionalinfo">';
							foreach($item['additionalinfo'] as $additionalInfo){
								$itemMarkup['additionalinfo'].='<span>'.$additionalInfo.'</span>';
							}
						$itemMarkup['additionalinfo'].='</div>';
					}
					$itemMarkup['tdclose']='</td>';
					$itemMarkup['price']='<td class="ogconnect-confirm-item-price">'.$cart['currency_left'].''.$item['price'].''.$cart['currency_right'].'</td>';
					$itemMarkup['quantity']='<td class="ogconnect-confirm-item-quantity">'.$item['count'].'x</td>';
					$itemMarkup['price_total']='<td class="ogconnect-confirm-item-price-total">'.$cart['currency_left'].''.$item['pricetotal'].''.$cart['currency_right'].'</td>';
					/**************************************************************************************************
						[added filter for customisation  v2.10.2]
						if you wish to customise the output, i would suggest you use the filter below in 
						your functions.php instead of editing this file (or a copy thereof in your themes directory)
					/**************************************************************************************************/
					$itemMarkup = apply_filters('ogconnect_filter_confirmation_item_markup', $itemMarkup, $item, $itemKey ,$options['order']);	
					/**output markup**/
					echo''.implode("",$itemMarkup).'';
				?>
				</tr>
				<?php } ?>
			</table>
			
<?php 
	/**************************************************************************************************************
		[cart (sub)-totals]
	**************************************************************************************************************/ 
?>
			<div id="ogconnect-confirm-cart-subtotals-wrap">
			<table id="ogconnect-confirm-cart-subtotals">
				<tr class="ogconnect-order-total-items"><td><?php echo $txt['order_items'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['total_price_items']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php if($cart['order_value']['discount']['val']>0){/*discount applies*/?>
					<tr class="ogconnect-order-discount"><td><?php echo $txt['discount'] ?></td><td><span class="ogconnect-minus"></span><?php echo $cart['currency_left'].''.$cart['order_value']['discount']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php } ?>			
				
				<?php if($cart['order_value']['item_tax']['val']>0 && $cart['tax_applied']=='items_only' && !$taxIncluded){/*item/sales tax applies (items only) AND prices entered WITHOUT tax */ ?>
					<tr class="ogconnect-order-item-tax"><td><?php echo $txt['item_tax_total'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['item_tax']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php } ?>
	
				<?php if(!isset($cart['self_pickup_enabled']) ||  $cart['selfPickup']==0){ /*no self pickup enabled or chosen :conditional */ ?>
					<?php if($cart['order_value']['delivery_charges']['val']!='' ){/*delivery charges if any*/?>
						<tr class="ogconnect-order-pickup"><td><?php echo $txt['delivery_charges'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['delivery_charges']['val'].''.$cart['currency_right']; ?></td></tr>
					<?php }else{ ?>
						<tr class="ogconnect-order-pickup"><td><?php echo $txt['delivery_charges'] ?></td><td><?php echo $txt['free_delivery'] ?></td></tr>
					<?php } ?>
				<?php } ?>
	
				<?php if($cart['order_value']['item_tax']['val']>0 && $cart['tax_applied']=='items_and_shipping' && !$taxIncluded){/*item/sales tax applied to items AND shipping AND prices entered WITHOUT tax */ ?>
					<tr class="ogconnect-order-item-tax"><td><?php echo $txt['item_tax_total'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['item_tax']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php } ?>
				
				<?php /**handling/sur charges if any**/ ?>
				<?php if(isset($cart['order_value']['handling_charge'])){ ?>
					<?php if(isset($cart['order_value']['handling_charge']['val'])){ /*is number, add currency symbol**/ ?>
						<tr class="ogconnect-order-handling-charge"><td><?php echo $txt['order_page_handling'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['handling_charge']['val'].''.$cart['currency_right']; ?></td></tr>
					<?php } ?>
					<?php if(isset($cart['order_value']['handling_charge']['str'])){ /*is string (i.e "surcharge calculated at checkout"), omit currency symbol**/  ?>
						<tr class="ogconnect-order-handling-charge-checkout"><td><?php echo $txt['order_page_handling'] ?></td><td><?php echo $cart['order_value']['handling_charge']['str']; ?></td></tr>
					<?php } ?>
				<?php } ?>
				
				<?php if(isset($cart['tips']) && $cart['tips']>0){/*tips NEW 2.8.4*/?>
					<tr class="ogconnect-order-tips"><td><?php echo $txt['tips'] ?></td><td><?php echo $cart['currency_left'].''.$cart['tips']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php } ?>
	
				<?php if($cart['order_value']['item_tax']['val']>0 && $taxIncluded){/*prices entered WITH tax, display at end before totals*/ ?>
					<tr class="ogconnect-order-item-tax"><td><?php echo $txt['item_tax_total'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['item_tax']['val'].''.$cart['currency_right']; ?></td></tr>
				<?php } ?>
				
			<?php
				/**added 2.11.2.4*/
				do_action('ogconnect_confirmationpage_before_totals',$cart);
			?>
	
				<tr class="ogconnect-cart-total"><td><?php echo $txt['order_total'] ?></td><td><?php echo $cart['currency_left'].''.$cart['order_value']['total']['val'].''.$cart['currency_right']; ?></td></tr>
			<?php
				/**added 2.11.2.4*/
				do_action('ogconnect_confirmationpage_after_totals',$cart);
			?>			
			</table>
			</div>
			
			<?php if(trim($txt['subtotals_after_additional_info'])!=''){?> 
				<div id="ogconnect-confirm-subtotals-after"><?php echo$txt['subtotals_after_additional_info'] ?></div>
			<?php } ?>
						
		<?php }else{ ?>
			<p><?php echo $txt['cart_is_empty'] ?></p>
		<?php } ?>
	</fieldset>
<?php 
/**************************************************************************************************************
*
*
*		[final buy / sendorder button and (required) hidden hash and gateway choice]
*		[do not change id's or names]
*
**************************************************************************************************************/ 
?>
	<?php if(count($cart['items'])>0){/*make sure there's stuff to order***/?>
	<div class="ogconnect-confirm-button">	
		<?php
			/*output the send order button*/
			echo $orderbutton;
		?>
	</div>
	<?php } ?>