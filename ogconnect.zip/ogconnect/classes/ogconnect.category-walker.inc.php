<?php
/********************************************************************************************

	get ogconnect categories in hierarchical sortorder

********************************************************************************************/
if (!class_exists( 'OGConnect' ) ) {return ;}

/**get ogconnect categories in hierarchical sortorder. returns pipe separated string of category id's in hierarchical order**/
class OGConnectCategoryHierarchyWalker extends Walker_Category {
    function start_el( &$output, $category, $depth = 0, $args = array(), $id = 0 ) {
		static $c=0;$c++;
		if($c>1){$output .='|';}/*to be used to explode/arrayise*/
		$output .= $category->term_id;
	}
}
?>