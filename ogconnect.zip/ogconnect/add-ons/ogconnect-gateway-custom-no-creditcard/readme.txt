=== OGConnect Gateway Custom===
Contributors: ollybach
Donate link: http://www.og-connect.com/
Author URI: http://www.og-connect.com
Plugin URI: http://og-connect.com/app
Tags: paypal, gateway, ogconnect
Requires at least: OGCONNECT 2.4, WP 3.5.1 
Tested up to: 3.5.1
Stable tag: 0.1


Custom Gateway for OGConnect - Requires OGCONNECT 2.4+

== Description ==

Custom Gateway for OGConnect - Custom Gateway for orders using the Wordpress OGCONNECT Plugin - Requires OGCONNECT 2.4+