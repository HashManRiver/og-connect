<?php
/*
Plugin Name: OGConnect Gateway Custom
Description: Custom Gateway for OGConnect - Requires OGCONNECT 2.4+
Author: ollybach
Plugin URI: http://www.og-connect.com
Author URI: http://www.og-connect.com
Version: 0.1

Copyright (c) 2012, Oliver Bach
All rights reserved.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--------------------------------------------------------------------------------------------
PLEASE DO REFER TO how-to.txt



*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


add_action( 'init', 'ogconnect_gateway_custom');
/*on uninstall, remove options from table*/
register_uninstall_hook( __FILE__, 'ogconnect_gateway_custom_uninstall');

function ogconnect_gateway_custom(){
	if (!class_exists( 'OGConnect' ) ) {return;}

		class OGCONNECT_GATEWAY_CUSTOM extends OGCONNECT_GATEWAYS {/**class must start with OGCONNECT_GATEWAY_  AND MUST BE UNIQUE**/

		function __construct() {
			$this->gatewayName = __('Custom Name',OGCONNECT_LOCALE);/*required gateway name*/
			$this->gatewayDescription = '';/*required variable (although it can be empty)- additional description of gateway displayed in ADMIN area*/
			$this->gatewayAdditionalInfo = '';/* required variable (although it can be empty) default printed under gateway options FRONTEND - can be changed/localized/emptied in admin */
			$this->gatewayOptionsName = strtolower(get_class());/*required - name of option in option table*/
			$this->gatewayOptions = get_option($this->gatewayOptionsName,0);/**required**/
			$this->gatewayTypeSubmit = 'ajax';/** 'ajax' to submit without going through any external/cc  processing (i.e to use ogconnect internal ajax submission of order in the samme way 'cod' orders are sent/processed**/
		}
		/**settings of gateway variables. required function, but can return empty array**/
		function gateway_settings($optionsOnly=false) {
				$gatewaySettings=array();
			return $gatewaySettings;
		}
	}
}
?>