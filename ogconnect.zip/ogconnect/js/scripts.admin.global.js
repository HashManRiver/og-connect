jQuery(document).ready(function($){
	/******************************
	*	[widget type has changed, show relevant option]
	******************************/
	$(document).on('change', '.ogconnect-select', function(e){
		self=$(this);
		self.closest('div').find('.ogconnect-selected>p').hide();
		self.closest('div').find('.ogconnect-selected>.ogconnect-selected-'+self.val()+'').fadeIn();
	});
})