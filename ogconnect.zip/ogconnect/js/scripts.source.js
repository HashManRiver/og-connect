var ogconnectClickEvent='click';/*leave for legacy reasons*/
var ogconnectShortcodeTotals = function(){};

jQuery(document).ready(function($){

	/*******************************************************
	*	[detect browser supported events
	*	and use touchstart if click is not supported
	*	avoids double trigger as using 'click touchstart'
	*	appears to trigger twice in Android devices
	*
	*	[DEPRECATED in favour of adding cursor:pointer to css
	*	for relevant elements]
	*
	*******************************************************/
//
//	var ogconnectCheckEventSupport = function(eventName){

//    	/*iSomething understands click, but doesnt want to do things with it so lets force touchstsrt*/
//    	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPad/i)) || (navigator.userAgent.match(/iPod/i))) {
//   			var bindEvent='touchstart';/*default to touchstart for iCrap*/
//   			return bindEvent;
//		}

//    	var el = document.createElement('div');
//    	eventName = 'on' + eventName;
//    	var isSupported = (eventName in el);
//    	if (!isSupported) {
//      		el.setAttribute(eventName, 'return;');
//      		isSupported = typeof el[eventName] == 'function';
//    	}
//    	el = null;
//    	var bindEvent='click';/*default touchstart*/
//    	if(!isSupported){
//    		bindEvent='touchstart';	/*if browser does not support touchstart, use click*/
//    	}
//    	return bindEvent;
//  	}
//  	ogconnectClickEvent=ogconnectCheckEventSupport("click");


	/****************************************************************************************************************************************************************************************************
	*
	*	[keep cart static on page when scrolling]
	*	[always adds ogconnect-cart-fixed class when scrolling is relevant so we can set things if needed]
	*	[will either be executed on page load or after the cart has been created if a cache plugin is used]
	****************************************************************************************************************************************************************************************************/
	var ogconnectCartStickyLoad= function(){
		var ogconnectCartStickyElm=$('.ogconnect-cart-sticky');/**get all elements*/
		var ogconnectCartStickyScrollTimeout;/**ini timeout*/
		/**********************
			[get bottom limit]
		***********************/
		var ogconnectCartStickyLimitBottomElm=false
		/**set bottom scroll limit by div id**/
		if(typeof ogconnect.crt.lmtb !=='undefined' && $('#'+ogconnect.crt.lmtb+'').length>0){
			ogconnectCartStickyLimitBottomElm=$('#'+ogconnect.crt.lmtb+'');/*set element*/
			var ogconnectCartStickyLimitOffset=0;/**set limit offset to be substracted from ogconnect.crt.mt  if required **/
			var ogconnectCartStickyLimitBottom=ogconnectCartStickyLimitBottomElm.offset().top;/*get element top*/
		}
		var ogconnectCartStickyScrollTop = $(window).scrollTop()+ogconnect.crt.mt;/*get top poxition where state toggle (browser + set margin)*/


		/**initialize a couple of vars vor the elements*/
		var ogconnectCartStickySelf = [];
		var ogconnectCartStickyVars = [];
		var ogconnectCartStickyParent = [];


		var ogconnectCartStickyAnimation = false;
		if(ogconnect.crt.anim>0 && ogconnect.crt.fx!=''){
			ogconnectCartStickyAnimation = true;
		}
		/**get all aplicable elements and their variables**/
		if(ogconnectCartStickyElm.length>0){
			$.each(ogconnectCartStickyElm,function(e,v){
				/***get the element object and add vars as required**/
				ogconnectCartStickySelf[e]=$(this);

				/**wrap in wraper div which is then set to height of cart to stop things jumping around**/
				ogconnectCartStickySelf[e].wrap( "<div class='ogconnect-cart-wrap'></div>" );

				ogconnectCartStickyVars[e]=ogconnectCartStickySelf[e].css(["backgroundColor"]);
				ogconnectCartStickyVars[e]['offset-top']= ogconnectCartStickySelf[e].offset().top;/*offset from top of page**/
				ogconnectCartStickyVars[e]['state']='';/**initialize state so - when set below - we dont ever need do the same thing multiple times**/
				ogconnectCartStickyVars[e]['height-int']=ogconnectCartStickySelf[e].height();/*make sure we also have height an integer and call it height-int instead of just height or jQuery 1.8.3 gets confused when SETTING height*/
				ogconnectCartStickyVars[e]['width-int']=ogconnectCartStickySelf[e].width();/*make sure we also have width an integer and call it width-int instead of just width or jQuery 1.8.3 gets confused when SETTING width*/

				/**set limit bottom**/
				if(ogconnectCartStickyLimitBottomElm && ogconnectCartStickyLimitBottom>(ogconnectCartStickyVars[e]['offset-top']+ogconnectCartStickyVars[e]['height-int'])){
					ogconnectCartStickyVars[e]['limit-bottom']=Math.floor(ogconnectCartStickyLimitBottom-ogconnectCartStickyVars[e]['height-int']);
				}

				/*get parent element so we can set height on it*/
				ogconnectCartStickyParent[e] = ogconnectCartStickySelf[e].parent();

				/*set distinct width of element so we dont have to set it all the time when scrolling or setting fixed position*/
				ogconnectCartStickySelf[e].width(ogconnectCartStickyVars[e]['width-int']);
				ogconnectCartStickyParent[e].height(ogconnectCartStickyVars[e]['height-int']);
			});
		}

		/***********************************************
		*	[we have set an element limit past which the
		*	sticky cart should not scroll,
		*	lets calculate the (negative) offset here]
		/***********************************************/
		var ogconnectCartStickyMaxOffset = function(elm,top,limitElm){
			var val=0;
			if(ogconnectCartStickyLimitBottomElm){
				var limit=limitElm.offset().top;/*get limit element top*/
				var elmOffset=Math.floor(limit-top-elm['height-int']);/*if negative we use it**/
				if(elmOffset<0){
					val=elmOffset;
				}
			}
			return val;
		};
		/**********no animation, just add/remove class, top and bg colour*******************************************************************************************************/
		if(!ogconnectCartStickyAnimation){
			/*let's rock n' scroll.....( oh dear )*/
			$(window).scroll(function () {
				var ogconnectCartStickyScrollTop = ($(window).scrollTop()+ogconnect.crt.mt);
				$.each(ogconnectCartStickySelf,function(e,v){

					/**calcuate needed offset if we are limiting the scroll by a set element below cart***/
					var ogconnectCartStickyLimitOffset=ogconnectCartStickyMaxOffset(ogconnectCartStickyVars[e],ogconnectCartStickyScrollTop,ogconnectCartStickyLimitBottomElm);

					/**leave it in place**/
					if (ogconnectCartStickyVars[e]['offset-top']>=ogconnectCartStickyScrollTop) {
						ogconnectCartStickySelf[e].removeClass('ogconnect-cart-fixed').css({'top':'','background-color':''+ogconnectCartStickyVars[e]['backgroundColor']+''});
					}
					/**set to fixed**/
					if (ogconnectCartStickyVars[e]['offset-top']<ogconnectCartStickyScrollTop) {
						ogconnectCartStickySelf[e].addClass('ogconnect-cart-fixed').css({'top':''+(ogconnect.crt.mt+ogconnectCartStickyLimitOffset)+'px','background-color':''+ogconnect.crt.bg+''});
					}
				});
			});
		}

		/**********with animation, *******************************************************************************************************************************************/
		if(ogconnectCartStickyAnimation){
		var ogconnectCartStickyAnimIni = true;/*set load flag*/

			/***********initialize on load***********/
			setTimeout(function(){/*a little timeout to give the page time to render*/
				$.each(ogconnectCartStickySelf,function(e,v){

					/**calcuate needed offset if we are limiting the scroll by a set element below cart***/
					var ogconnectCartStickyLimitOffset=ogconnectCartStickyMaxOffset(ogconnectCartStickyVars[e],ogconnectCartStickyScrollTop,ogconnectCartStickyLimitBottomElm);

					/**leave it in place**/
					if (ogconnectCartStickyVars[e]['offset-top']>=ogconnectCartStickyScrollTop) {
						ogconnectCartStickyVars[e]['state']='relative';/*set state flag so we dont do the same thing  multiple times**/
					}
					/**move to sticky/fixed**/
					if (ogconnectCartStickyVars[e]['offset-top']<ogconnectCartStickyScrollTop) {
						ogconnectCartStickySelf[e].addClass('ogconnect-cart-fixed').css({'background-color':''+ogconnect.crt.bg+'','top':'0'});
						ogconnectCartStickySelf[e].animate({'top':''+(ogconnect.crt.mt+ogconnectCartStickyLimitOffset)+'px'},ogconnect.crt.anim,''+ogconnect.crt.fx+'',function(){});
						ogconnectCartStickyVars[e]['state']='fixed';/*set state flag so we dont do the same thing  multiple times**/
					}
				});
				ogconnectCartStickyAnimIni=false;/*unset previously set load flag*/
			},200);


			/*********on scroll after load *************/
			$(window).scroll(function () {
				if(!ogconnectCartStickyAnimIni){/*only react to scrolling after initial load*/

					var ogconnectCartStickyScrollTop = $(window).scrollTop()+ogconnect.crt.mt;/*find out if we need fixed or relative*/

						clearTimeout(ogconnectCartStickyScrollTimeout);
						ogconnectCartStickyScrollTimeout = setTimeout(function(){/*a little timeout to not go mad*/
							/*iterate through elements*/
							$.each(ogconnectCartStickySelf,function(e,v){

								/**calcuate needed offset if we are limiting the scroll by a set element below cart***/
								var ogconnectCartStickyLimitOffset=ogconnectCartStickyMaxOffset(ogconnectCartStickyVars[e],ogconnectCartStickyScrollTop,ogconnectCartStickyLimitBottomElm);

								/**put back in its place if state has changed, otherwise just leave in peace**/
								if (ogconnectCartStickyVars[e]['offset-top']>=ogconnectCartStickyScrollTop && ogconnectCartStickyVars[e]['state']!='relative') {
									ogconnectCartStickyVars[e]['state']='relative';/*set state flag so we dont do the same thing  multiple times**/

									ogconnectCartStickySelf[e].removeClass('ogconnect-cart-fixed');
									ogconnectCartStickySelf[e].animate({'top':''},ogconnect.crt.anim,''+ogconnect.crt.fx+'',function(){
										ogconnectCartStickySelf[e].css({'background-color':''+ogconnectCartStickyVars[e]['backgroundColor']+''});
									});
									// if we do not want to animate when returning to relative state , use this instead of the above.
									//ogconnectCartStickySelf[e].removeClass('ogconnect-cart-fixed').css({'top':'','background-color':''+ogconnectCartStickyVars[e]['backgroundColor']+''});
								}
								/**move to sticky/fixed if state has changed or we have a limit set , otherwise just leave in peace**/
								if (ogconnectCartStickyVars[e]['offset-top']<ogconnectCartStickyScrollTop && (ogconnectCartStickyVars[e]['state']!='fixed' || ogconnectCartStickyLimitBottomElm)) {

									ogconnectCartStickyVars[e]['state']='fixed';/*set state flag so we dont do the same thing  multiple times**/
									ogconnectCartStickySelf[e].addClass('ogconnect-cart-fixed').css({'background-color':''+ogconnect.crt.bg+''});
									ogconnectCartStickySelf[e].animate({'top':''+(ogconnect.crt.mt+ogconnectCartStickyLimitOffset)+'px'},ogconnect.crt.anim,''+ogconnect.crt.fx+'',function(){});
								}
							});
					},100);
				}
			});
		}
	}
	/*******************************************************
	*
	*	[add spinner to order page for increase/decrease of items if enabled]
	*
	*******************************************************/
  	if(typeof ogconnect.ofqc!=='undefined'){
  		var spinnerElm=$( "#ogconnect-send-order .ogconnect-item-quantity" );
       	spinnerElm.spinner({ min: 0});/*set min var*/

		/*restrict scrollwheel to be >=0*/
		spinnerElm.on( 'DOMMouseScroll mousewheel', function ( event ) {
		  if( event.originalEvent.detail > 0 || event.originalEvent.wheelDelta < 0 ) { //alternative options for wheelData: wheelDeltaX & wheelDeltaY
		    // down
		    if (parseInt(this.value) > 0) {
		    	this.value = parseInt(this.value, 10) - 1;
		    }
		  } else {
		  	// up
		  	this.value = parseInt(this.value, 10) + 1;
		  }
		  //prevent page from scrolling
		  return false;
		});


		/**stop submitting if we are hitting enter after changing quantities and update those instead**/
		spinnerElm.keydown(function(event) {
			if(event.which == 13 || event.which == 35){
				event.preventDefault();
				$('.ogconnect-update-order').trigger('click');
			return false;
			}
		});

       /**do the update**/
       $(document).on('click', '.ogconnect-update-order', function(e){
       	/*get the elemenst and create a key value array to send to ajax**/
       	var ogconnectCartCurrElms=$(".ogconnect-item-quantity");
       	var updtElms={};
       	$.each(ogconnectCartCurrElms,function(e,v){
       		var self=$(this);
       		var id=$(this).attr('id').split('-');
       		var val=$(this).val();
       		updtElms[id[2]]=val;
       	});
       	$('html').css({'position':'relative'});/*stretch html to make loading cover whole page*/
     	$('body').prepend('<div id="ogconnect-loading" style="opacity:0.8"></div>');
     	/**now send ajax to update**/
		jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'ogconnect-update-order','data':updtElms}}, function(response) {
			window.location.href=window.location.href;/*make sure page gest reloaded without confirm*/
			return;			
		},'json').error(function(jqXHR, textStatus, errorThrown) {	$('body>#ogconnect-loading').remove(); alert("error : " + errorThrown);console.log(jqXHR.responseText);});
       });
  	}
	/*******************************
	*	[add to cart / remove from cart]
	*******************************/
	/**only allow integers in cart increase/decrease**/
	$(document).on('keyup', '.ogconnect-cart-incr', function(e){
		this.value = this.value.replace(/[^0-9]/g,'');
		/**when using textbox in cart to incr/decr allow enter/end (iphone) as well as clicking on button */
		if(e.keyCode == 13 || e.keyCode == 35){
			$(this).closest('li').find('.ogconnect-cart-increment').trigger('click');
		}
	});


	/**run defined functions after cart refresh**/
	var ogconnectCartRefreshed = (function(functionArray, res) {
		if(functionArray.length>0){
			for(i=0;i<functionArray.length;i++){
				var func = new Function("term", "return " + functionArray[i] + "(term);");
				func(res);
			}
		}
	});

	$(document).on('click', '.ogconnect-add-to-cart,.ogconnect-remove-from-cart,.ogconnect-cart-refresh,#ogconnect-force-refresh,.ogconnect-cart-increment,.ogconnect-empty-cart-button', function(e){
		if ($(".ogconnect-open").length > 0){//first check if shopping cart exists on page and that we are open
			e.preventDefault();
			e.stopPropagation();

		/**if on orderpage, cover whole page**/
		if(typeof ogconnect.isCheckout!=='undefined'){
       		$('html').css({'position':'relative'});/*stretch html to make loading cover whole page*/
     		$('body').prepend('<div id="ogconnect-loading" style="opacity:0.8"></div>');
			$('.ogconnect-ordernow').attr("disabled", "true");//disable send order button
		}else{
			$('.ogconnect-order').prepend('<div id="ogconnect-loading"></div>');
		}


		var self=$(this);
		var selfId=self.attr('id');
		var cartButton=$('.ogconnect-cart-button input,.ogconnect-cart-button>a,.ogconnect-empty-cart-button');
		cartButton.attr("disabled", "true");/*disable place order button to stop trying to order whilst stuff is being added to the cart*/
		/**feedback on item add enabled ? - always skip if triggered from add_to_cart_button shortcode*/
		var fbatc=false;
		if(typeof ogconnect.itm!=='undefined' && typeof ogconnect.itm.fbatc!=='undefined' && !self.hasClass('ogconnect-add-to-cart-btn')){
		 fbatc=true;
		}

		var itemCount=1;
		/**get cat id**/
		var catId='';
		if(self.hasClass('ogconnect-add-to-cart')){
			type='add';
			var postCatId = selfId.split('-');
			var catdata = self.closest('article').find('#ogconnect-category-'+postCatId[1]+'').val();
			if(typeof catdata!=='undefined'){/*some customised templates may not have catid added, so check first*/
				catId=catdata;
			}
		}
		if(self.hasClass('ogconnect-remove-from-cart')){type='remove';}
		if(self.hasClass('ogconnect-empty-cart-button')){type='removeall';selfId=0;}
		if(self.hasClass('ogconnect-cart-refresh') || selfId=='ogconnect-force-refresh'){type='refresh';}
		if(self.hasClass('ogconnect-cart-increment')){
			var itemCount=self.closest('li').find('.ogconnect-cart-incr').val();
			if(itemCount==0){
				type='remove';
			}else{
				type='increment';
			}
		}
			if(type!='removeall' && type!='add' ){
				self.fadeOut(100).fadeIn(400);
			}
			if(!fbatc && type=='add'){/*make this dedicated for add*/
				self.fadeOut(100).fadeIn(400);
			}
			if(fbatc && type=='add'){
				var currentHtml=self.html();
				self.fadeOut(100, function(){
					self.html( "<div class='ogconnect-item-added-feedback'>"+ogconnect.itm.fbatc+"</div>" ).fadeIn(400).delay(ogconnect.itm.fbatcms).fadeOut(400,function(){
						self.html(currentHtml).fadeIn(100);
					});
				});
			}

			jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':type,'id':selfId,'itemCount':itemCount,'catId':catId}}, function(response) {
				/**if on orderpage, just reload**/
				if(typeof ogconnect.isCheckout!=='undefined'){
					window.location.href=window.location.href;/*make sure page gest reloaded without confirm*/
					window.location.reload(true);
					return;
				}

				/*show items in cart*/
				$('.ogconnect-order').html(response.itemsajax);
				/*button*/
				$('.ogconnect-cart-button').html(response.button);

				/*minimum order not reached*/
				$('.ogconnect-cart-nocheckout').html(response.nocheckout);
				/*order summary*/
				$('.ogconnect-cart-total-items-label').html(response.order_value.total_price_items.lbl);
				$('.ogconnect-cart-total-items-value').html(response.currency_left+''+response.order_value.total_price_items.val+''+response.currency_right);
				if(response.nocheckout==''){
					$('.ogconnect-cart-discount-label').html(response.order_value.discount.lbl);

					/*addcurrency if discount applies**/
					if(response.order_value.discount.val!=''){
						$('.ogconnect-cart-discount-value').html('<span class="ogconnect-minus"></span>'+response.currency_left+''+response.order_value.discount.val+''+response.currency_right);
					}else{
						$('.ogconnect-cart-discount-value').html(response.order_value.discount.val);
					}
					$('.ogconnect-cart-delivery-charges-label').html(response.order_value.delivery_charges.lbl);
					/*addcurrency if its not free delivery**/
					if(response.order_value.delivery_charges.val!=''){
					$('.ogconnect-cart-delivery-charges-value').html(response.currency_left+''+response.order_value.delivery_charges.val+''+response.currency_right);
					}else{
					$('.ogconnect-cart-delivery-charges-value').html(response.order_value.delivery_charges.val);
					}
					/**tax**/
					$('.ogconnect-cart-tax-label').html(response.order_value.item_tax.lbl);
					$('.ogconnect-cart-tax-value').html(response.currency_left+''+response.order_value.item_tax.val+''+response.currency_right);

					/**tax included**/
					$('.ogconnect-cart-tax-included-label').html(response.order_value.taxes_included.lbl);
					$('.ogconnect-cart-tax-included-value').html(response.currency_left+''+response.order_value.taxes_included.val+''+response.currency_right);

					$('.ogconnect-cart-total-label').html(response.order_value.total.lbl);
					$('.ogconnect-cart-total-value').html(response.currency_left+''+response.order_value.total.val+''+response.currency_right);
				}
				if(response.nocheckout!='' || response.items.length==0){
					$('.ogconnect-cart-discount-label').html('');
					$('.ogconnect-cart-discount-value').html('');
					$('.ogconnect-cart-delivery-charges-label').html('');
					$('.ogconnect-cart-delivery-charges-value').html('');
					$('.ogconnect-cart-total-label').html('');
					$('.ogconnect-cart-total-value').html('');
					$('.ogconnect-cart-tax-label').html('');
					$('.ogconnect-cart-tax-value').html('');
					$('.ogconnect-cart-tax-included-label').html('');
					$('.ogconnect-cart-tax-included-value').html('');

				}
				if(response.items.length==0){
					$('.ogconnect-cart-total-items-label').html('');
					$('.ogconnect-cart-total-items-value').html('');
				}

				cartButton.removeAttr("disabled");/*re-enable place order button*/

				ogconnectCartRefreshed(ogconnect.funcCartRefr,response);

			},'json').error(function(jqXHR, textStatus, errorThrown) {console.log("error : " + errorThrown);console.log(jqXHR.responseText);$('.ogconnect-order #ogconnect-loading').remove();});
		}});

	/***********************************************
	*
	*	[if there's a shopping cart on the page
	*	but we are currently closed, display alert]
	*
	***********************************************/
	$(document).on('click', '.ogconnect-add-to-cart', function(e){
		if ($(".ogconnect-open").length == 0 &&  $(".ogconnect-cart").length > 0){
			alert(ogconnect.msg.closed);
	}});
	/***********************************************
	*
	*	[customer selects self pickup , session gets set via ajax
	*	reload page to reflect delivery charges....
	*	only relevant if there's a shoppingcart or orderpage on page]
	*	[as it's an input element always use click instead of touchstart, cause iStuff is stupid]
	***********************************************/
	$(document).on('click', '#ogconnect-order-pickup-sel, #ogconnect-order-pickup-js', function(e){
		if (($(".ogconnect-open").length > 0 &&  $(".ogconnect-cart").length > 0) || $("#ogconnect-send-order").length>0){
			var self=$(this);
			self.attr("disabled", true);/*disable checkbox to give ajax time to do things*/
			var selfValue=self.is(':checked');
			/*js alert if enabled*/
			if(self.attr('id')=='ogconnect-order-pickup-js'){
				/**make user confirm**/
				if(typeof ogconnect.opt!=='undefined' && typeof ogconnect.opt.pickupConfirm!=='undefined'){
					if(confirm(ogconnect.msg.pickup)){
					//just continue
					}else{
						if(selfValue){
							self.attr('checked',false);//restore cheked attribute
						}else{
							self.attr('checked',true);//restore cheked attribute
						}
						self.attr("disabled", false);//make it selectable again
					return;
					}
				}else{
					if(selfValue==true){
						alert(ogconnect.msg.pickup);
					}
				}
			}
			jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'order-pickup','value':selfValue,'data':$('#ogconnect-send-order').serialize(),'locHref':location.href,'urlGetVars':location.search}}, function(res) {
				var anchor='';
				if(typeof res.anchor!=='undefined'){
					anchor=res.anchor;
				}
				window.location.href=res.location+anchor;/*make sure page gest reloaded without confirm*/
				window.location.reload(true)
				return;
			},'json').error(function(jqXHR, textStatus, errorThrown) {alert("error : " + errorThrown);console.log(jqXHR.responseText);});
	}});

	/******************************************************
	*
	*	[changing gateways, re-calculate handling charges
	*	if any are >0 which will in turn add the hidden field
	*	'#ogconnect_calc_handling' we are checking first ]
	******************************************************/
	if($('#ogconnect_calc_handling').length>0){
		var ogconnectGatewaySelected = $("input[name='ogconnect-gateway']");
		if(ogconnectGatewaySelected.length==0){
			ogconnectGatewaySelected = $("select[name='ogconnect-gateway']");
		}
		ogconnectGatewaySelected.change(function(e){
			$('#ogconnect-send-order').prepend('<div id="ogconnect-loading"></div>');
			if(ogconnectGatewaySelected.is(':radio')){
				var selectedGateway = $("input[name='ogconnect-gateway']:checked").val();
			}else{
				var selectedGateway = $("select[name='ogconnect-gateway']").val();
			}
			jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'ogconnect-select-gateway','data':$('#ogconnect-send-order').serialize(),'selgw':selectedGateway}}, function(res) {
				window.location.href=window.location.href;/*make sure page gest reloaded without confirm*/
				//window.location.reload(true);
				return;				
			},'json').error(function(jqXHR, textStatus, errorThrown) {	$('#ogconnect-send-order #ogconnect-loading').remove(); alert("error : " + errorThrown);console.log(jqXHR.responseText);});
		});
	}
	/***********************************************
	*
	*	[if we are trying to add to cart by clicking on the title
	*	but there's more than one size to choose from, display alert]
	*	[provided  there's a cart on page and we are open]
	***********************************************/
	/*more than one size->choose alert*/
	$(document).on('click', '.ogconnect-trigger-choose', function(e){
		if ($(".ogconnect-open").length > 0 &&  $(".ogconnect-cart").length > 0){
			alert(ogconnect.msg.choosesize);
	}});
	/*only one size, trigger click*/
	$(document).on('click', '.ogconnect-trigger-click', function(e){
		if ($(".ogconnect-open").length > 0 &&  $(".ogconnect-cart").length > 0){
			/*just loose ogconnect-article- from id*/
			 var ArticleId=this.id.split("-");
			ArticleId=ArticleId.splice(2);
			ArticleId = ArticleId.join("-");
			/**make target id*/
			target=$('#ogconnect-'+ArticleId+'');
			/*trigger*/
			target.trigger('click');
	}});

	/***********************************************
	*
	*	[order form: login or continue as guest]
	*
	***********************************************/
	$(document).on('click', '#ogconnect-login,#ogconnect-login-cancel', function(e){
		$("#ogconnect-user-login-action").toggle(300);
		$("#ogconnect-user-login-option>span>a").toggle();
	});
	$(document).on('click', '#ogconnect_btn_login', function(e){/**changed to click so iphone understands it too*/
		$("#ogconnect-user-login-action").append('<div id="ogconnect-loading"></div>');
	});
	$(document).on('change', '#ogconnect_account', function(e){
		$("#ogconnect-user-register-info" ).toggle(200);
		$(".ogconnect-login-error").remove();

	});
	/****insert nonce too via js *******/
	if($("#ogconnect-send-order").length>0){
		jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'nonce','val':'register'}}, function(nonce) {
			$('#ogconnect-create-account').append(nonce);
		},'html').error(function(jqXHR, textStatus, errorThrown) {alert("error : " + errorThrown);console.log(jqXHR.responseText);});
	}


	/*******************************************************************
	*	[validate and submit order page]
	*	gateway could be either by dropdown,
	*	radio, or if only one, hidden elm
	*******************************************************************/
	$(document).on('click', '.ogconnect-ordernow', function(e){
		$('#ogconnect-send-order').validate().settings.ignore = "";
	});
	/*******************************
	*	[validate tips/gratuities]
	*******************************/
	/**current tip value set **/
	var ogconnectTipsField=$("#ogconnect-send-order #ctips");
	var ogconnectCTipsCurr=ogconnectTipsField.val();
	/**stop submitting form if we are hitting enter on tip field and just apply tip**/
	ogconnectTipsField.keydown(function(event) {
		if(event.which == 13 || event.which == 35){
			event.preventDefault();
			$('#ogconnect-ctips-btn').trigger('click');
		return false;
		}
	});

	/**click should work here even on iStupid as it's a button **/
	$(document).on('click', '#ogconnect-ctips-btn', function(e){
		/*we only want to validate the tips, so lets igmore everythig else*/
		$('#ogconnect-send-order').validate().settings.ignore = "#ogconnect-send-order>fieldset>input,#ogconnect-send-order>fieldset>textarea,#ogconnect-send-order>fieldset>select";
		var isValid=$("#ogconnect-send-order").valid();
		if(isValid){
			var ogconnectCTipsNew=$("#ogconnect-send-order #ctips").val();
			/**only update/refresh if the value has actually changed**/
	  		if(ogconnectCTipsCurr!=ogconnectCTipsNew){
	  			$("#ogconnect-send-order").prepend('<div id="ogconnect-loading" style="opacity:0.8"></div>');
				jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'add_tips','data':$('#ogconnect-send-order').serialize(),'locHref':location.href,'urlGetVars':location.search}}, function(res) {
				window.location.href=res.location;/*make sure page gest reloaded without confirm*/
				return;				
				},'json');
	  		}
		}
	});
	/*******************************************
	*	[validation login]
	*******************************************/
	$("#ogconnect-login-frm").validate({});
	/*******************************************
	*	[ini validation]
	*******************************************/
	$("#ogconnect-send-order").validate({
			rules: {
	   			ctips: {
	      			number: true
	    		}
	  		},
	  		invalidHandler: function(form, validator) {

		        if (!validator.numberOfInvalids()){
		            return;
		        }
		        /**check if element is in view*/
  				var errorElem = $(validator.errorList[0].element);
    			var currentWindow = $(window);

    			var docViewTop = currentWindow.scrollTop();
    			var docViewBottom = docViewTop + currentWindow.height();

			    var elemTop = errorElem.offset().top;
    			var elemBottom = elemTop + errorElem.height();

		        var inView= ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));

		        /**scroll into view if needed*/
		        if(!inView){
		        	$('html, body').animate({
			            scrollTop: errorElem.offset().top-20
		        	}, 300);
		        }
  			},
			submitHandler: function(form) {
				$('.ogconnect-ordernow').attr('disabled', 'true');//stop double clicks
				var hasClassAjax=false;
				var hasClassCustom=false;
				if($("input[name='ogconnect-gateway']").length>0){
					var elm = $("input[name='ogconnect-gateway']");
					if(elm.is(':radio')){
						var selected = $("input[name='ogconnect-gateway']:checked");
					}else{
						var selected = elm;
					}
					hasClassAjax=selected.hasClass("ogconnectGwAjaxSubmit");
					hasClassCustom=selected.hasClass("ogconnectGwCustom");
				}else{
					var selected = $("select[name='ogconnect-gateway']");
					hasClassAjax=$("select[name='ogconnect-gateway'] option:selected").hasClass("ogconnectGwAjaxSubmit");
					hasClassCustom=$("select[name='ogconnect-gateway'] option:selected").hasClass("ogconnectGwCustom");
				}

				var self=$('#ogconnect-send-order');
				var currVal = selected.val();
				var profileUpdate=$("#ogconnect_profile_update").is(':checked');
				if(profileUpdate==true){
					jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'profile_update','data':self.serialize()}}, function(response) {
						//console.log(response);
					},'html');
				}

				/***if we want to also register account check this first**/
				var ogconnectLoginElm=$("#ogconnect-user-login");
				var ogconnectLoginErr=$(".ogconnect-login-error");/*remove any previous errors*/
				if(ogconnectLoginErr.length>0){
					ogconnectLoginErr.remove();
				}

				var ogconnectLoginSelect=$("input[type=radio][name='ogconnect_account']:checked");

				ogconnectLoginElm.hide();
				if(typeof ogconnectLoginSelect!=='undefined' && ogconnectLoginSelect.val()=='register'){
					self.prepend('<div id="ogconnect-loading"></div>');
					jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'new-account','data':self.serialize()}}, function(response) {
						/**account/email exists**/
						if(typeof response.error!=='undefined'){
							$('#ogconnect-user-register-info').append(response.error);
							$('#ogconnect-send-order #ogconnect-loading').remove();
							ogconnectLoginElm.show();
							return;
						}
						/***all is well. go ahead with stuff**/
						if(typeof response.error==='undefined'){
							ogconnectSelectSubmitType(self,currVal,hasClassAjax,hasClassCustom,form);
						}
					},'json');
					return;
				}else{
					/**we are not registering a new account, so just submit as planned**/
					ogconnectSelectSubmitType(self,currVal,hasClassAjax,hasClassCustom,form);
				}
			}
		});


	/******************************
	* submit via ajax or send form
	*******************************/
	var ogconnectSelectSubmitType=function(self,currVal,hasClassAjax,hasClassCustom,form){
		/*****confirmation page enabled*****/
		if(typeof ogconnect.cfrm!=='undefined' && !self.hasClass('ogconnect-confirm-order')){
			$('#ogconnect-user-login').empty().remove();
			self.prepend('<div id="ogconnect-loading"></div>');
			jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'confirmorder','data':self.serialize(),'hasClassAjax':hasClassAjax,'hasClassCustom':hasClassCustom}}, function(response) {
						self.html(response);//replace the form contents
						self.addClass('ogconnect-confirm-order');/*set class so we dont do this again**/
						$('#ogconnect-send-order #ogconnect-loading').remove();
			},'html').error(function(jqXHR, textStatus, errorThrown) {$('#ogconnect-send-order #ogconnect-loading').remove();alert("error : " + errorThrown);console.log(jqXHR.responseText);});
			return;
		}

		/**first make sure we are still open, as a customer may have been staying on th eoreder page for ages and shop is now closed**/
		jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'checkifopen'}}, function(response) {
			if(typeof response.isclosed!=='undefined'){
				alert(response.isclosed);
				window.location.href=window.location.href;/*make sure page gest reloaded without confirm*/
				window.location.reload(true);
				return;
			}

			/**customised submit/payment via js window/overlay for example - will have to provide its own script**/
			if(hasClassCustom){
				/**custom js of gateway*/
				window['ogconnect' + currVal + 'payment']();

				/***also save set customr data input fields in session data**/
				jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'ogconnect-set-userdata','data':$('#ogconnect-send-order').serialize()}}, function(res) {
					//console.log('res');
				},'json').error(function(jqXHR, textStatus, errorThrown) {	$('#ogconnect-send-order #ogconnect-loading').remove(); alert("error : " + errorThrown);console.log(jqXHR.responseText);});				

				return;
			}
			/**cod->transmit form via ajax if cod or forced by gw settings (i.e $this->gatewayTypeSubmit = 'ajax')*/
			if(currVal=='cod' || hasClassAjax){
				self.prepend('<div id="ogconnect-loading"></div>');
				$('#ogconnect-user-login').empty().remove();
				jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'sendorder','data':self.serialize()}}, function(response) {
					$('html, body').animate({scrollTop : 0},300);/*scroll to top*/
					$('#ogconnect-send-order #ogconnect-loading').remove();
					self.html('<div id="ogconnect-order-received">'+response+'</div>');
				},'html').error(function(jqXHR, textStatus, errorThrown) {$('#ogconnect-send-order #ogconnect-loading').remove();alert("error : " + errorThrown);console.log(jqXHR.responseText);});
			}else{
				self.prepend('<div id="ogconnect-loading" style="opacity:0.8;"></div>');
				form.submit();
				return;
			}

		},'json').error(function(jqXHR, textStatus, errorThrown) {$('#ogconnect-send-order #ogconnect-loading').remove();alert("error : " + errorThrown);console.log(jqXHR.responseText);});

	};
	/******************************
	* set error messages
	*******************************/
	jQuery.extend(jQuery.validator.messages, {
    	required: ogconnect.validate_error.required,
    	email: ogconnect.validate_error.email,
    	number: ogconnect.validate_error.decimal
	});
	/**allow for commas in number validation but no negatives**/
	$.validator.methods.number = function (value, element) {
	    return this.optional(element) || /^(?:\d+|\d{1,3}(?:[\s\.,]\d{3})+)(?:[\.,]\d+)?$/.test(value);
	    //return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:[\s\.,]\d{3})+)(?:[\.,]\d+)?$/.test(value);//this would allow negatives too
	}
	/******************************
	* Let's make IE7 IE8 happy and stop submitting while other stuff is going on such as adding items etc
	*******************************/
	$(document).on('click', '.ogconnect-cart-button>a', function(e){
		e.preventDefault(); e.stopPropagation();
		var attr = $(this).attr('disabled');
		if (typeof attr !== 'undefined' && attr !== false){}else{
        	var url=jQuery(this).attr("href");
	        window.location.href = url;
			return;	        
		}
	});
	/***********************************************
	*
	*	[using cache plugin, load cart dynamically]
	*	[as the cart does not exist onload we will also
	*	have to execute the sticky cart function after it has been created]
	***********************************************/
	if(typeof ogconnect.usingCache!=='undefined'){
		var ogconnectNoCacheAttr=$('#ogconnect-cart-nocache-attributes').val();
		jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'hasCachePlugin','attributes':ogconnectNoCacheAttr}}, function(response) {
			$('.ogconnect-cart-nocache').html(response.markup);
			ogconnectCartRefreshed(ogconnect.funcCartRefr,response.cart);/**also run any cart refreshed functions**/
		},'json').complete(
			function(){ogconnectCartStickyLoad();}/*on complete, exec sticky cart if enabled*/
		).error(function(jqXHR, textStatus, errorThrown) {alert("error : " + errorThrown);console.log(jqXHR.responseText);});
	}else{
		/*if no cache, just exec sticky cart function*/
		ogconnectCartStickyLoad();
	}

	/***********************************************
	*
	*	hijacking other cpts (or just a button with dropdown elsewhere)
	*	adding an add to cart button linked to a specific menu item
	*	selecting from dropdown
	***********************************************/
	/*set id on trigger element when dropdown changes*/
	$(document).on('change', '.ogconnect-add-to-cart-size', function(e){
       	var self=$(this);
       	/**add class*/
       	//self.addClass('ogconnect-add-to-cart');
		/*get id*/
       	var id=$(this).attr('id');
       	var postid=id.split('-').pop(-1);
       	var selVal=$('#ogconnect-add-to-cart-size-'+postid+'').val();
		/*set id on element to trigger*/
		var elm=self.closest('span').find('.ogconnect-add-to-cart').prop('id', 'ogconnect-'+selVal+'');
	});
	/**trigger click on element when button clicked*/
	$(document).on('click', '.ogconnect-add-to-cart-select', function(e){
		var self=$(this);
		var triggerElm=self.next();
		triggerElm.trigger('click');
	});
	/***********************************************
	*
	*	[using totals shortcode,load via js]
	*
	***********************************************/
	ogconnectShortcodeTotals = function(){
		if ($(".ogconnect-totals").length > 0){
			jQuery.post(ogconnect.ajaxurl , {action :'ogconnect_json',vars:{'type':'gettotals'}}, function(res) {
				var curr=$(".ogconnect-totals-currency");
				var total=$(".ogconnect-total");
				var itemcount=$(".ogconnect-totals-itemcount");
				var button=$(".ogconnect-totals-checkout-button");
				var viewcart=$(".ogconnect-totals-viewcart");

				/**no items in cart**/
				if(res.items.length<=0){
					curr.html(res.currency);
					total.html(res.order_value.total_price_items.val);
					if (itemcount.length > 0){
						itemcount.html('&nbsp;');//empty if 0
					}
					if (viewcart.length > 0){
						viewcart.html('&nbsp;');//empty if 0
					}
				}else{
					curr.html(res.currency);
					if ($(".ogconnect-total-items").length > 0){
						total.html(res.order_value.total_price_items.val);
					}else{
						total.html(res.order_value.total.val);
					}
					/**item count*/
					if (itemcount.length > 0){
						itemcount.html(res.itemcount);
					}
					/**viewcart */
					if (viewcart.length > 0){
						viewcart.html(res.viewcart);
					}					
				}
				/*print button (will be emoty if no item in cart**/
				button.html(res.button);

			},'json').error(function(jqXHR, textStatus, errorThrown) {$('#ogconnect-send-order #ogconnect-loading').remove();alert("error : " + errorThrown);console.log(jqXHR.responseText);});
		}
	}
	ogconnectShortcodeTotals();

	/***********************************************
	*
	*	[show minicart if main cart is not in view]
	*	(provided it's enabled of course)
	***********************************************/
	ogconnectMiniCart = function(){
		var miniCartElm=$("#ogconnect-mini-cart");
		var ogconnectCartCached=$(".ogconnect-cart-nocache");

		if (miniCartElm.length > 0){

			/**current window**/
			var currentWindow = $(window);
			/**current elm top padding**/
			//var elmPaddingTop=$("body").css("padding-top");
						
    		/**set padding to element if set**/
    		if(typeof ogconnect.crt.mCartPadTop !=='undefined'){
    			var addElmPaddingTop=ogconnect.crt.mCartPadTop;		
				/**add padding to set elements**/
				if(typeof ogconnect.crt.mCartPadElm!=='undefined'){	
					var elmToPad=$(''+ogconnect.crt.mCartPadElm+'');
				}else{    			
    				var elmToPad=$('body');
				}
    		}			
			
			/**get the element in use*/
			if(ogconnectCartCached.length>0){
				/**using cart with cache**/
				var mainCartElm = ogconnectCartCached;
			}else{
				var mainCartElm = $('.ogconnect-cart');
			}
			/*add to id.class instead of body if set*/
			if(typeof ogconnect.crt.mCartElm !=='undefined'){
				miniCartElm.prependTo(''+ogconnect.crt.mCartElm+'');
			}
			/*always shown, display and skip everything after*/
			if(typeof ogconnect.crt.mCartStatic!=='undefined'){
				
				/**add padding to set elements**/
				if(typeof elmToPad!=='undefined'){	
					elmToPad.css({'padding-top': '+='+addElmPaddingTop+'px'});
				}
				return;
			}			
			
			var miniCartIni=true;
			
			/**on initial load**/		        
		    setTimeout(function(){
		    	ogconnectMiniCartDo(currentWindow, miniCartElm, mainCartElm, addElmPaddingTop, elmToPad);
		    	miniCartIni=false;
		    },500);
		    
		    /**on scroll**/
		    var showMiniCart;
			$(window).scroll(function () {
				/**only on subsequent scrolls not when page is already scrolled on load*/
				if(!miniCartIni){
					clearTimeout(showMiniCart);
					showMiniCart=setTimeout(function(){
						ogconnectMiniCartDo(currentWindow, miniCartElm, mainCartElm,addElmPaddingTop, elmToPad);
					},300);
				}
			});
		    /**on resize**/    
		    $(window).resize(function() {
				/**only on subsequent scrolls not when page is already scrolled on load*/
				if(!miniCartIni){
					clearTimeout(showMiniCart);
					showMiniCart=setTimeout(function(){
						ogconnectMiniCartDo(currentWindow, miniCartElm, mainCartElm,addElmPaddingTop, elmToPad);
					},300);
				}
			});
		}
	}
	ogconnectMiniCart();
	
	var ogconnectMiniCartDo = function(currentWindow, miniCartElm, mainCartElm, addElmPaddingTop, elmToPad){	

		/*get width**/
    	var docViewWidth = currentWindow.width();
    	/*max width**/
    	if(typeof ogconnect.crt.mCartMaxWidth !=='undefined'){
    		var docWidthLimit=ogconnect.crt.mCartMaxWidth;
    	}
    	
		/**skip if wider than max width set or on oderpage**/
		if((typeof docWidthLimit !=='undefined' && docViewWidth>docWidthLimit) || typeof ogconnect.isCheckout!=='undefined'){
			/*in case its still visible*/
			if(miniCartElm.is(':visible')){
				miniCartElm.fadeOut(250);	
			}
			return;
		}
    	
    	var docViewTop = currentWindow.scrollTop();
    	var docViewBottom = docViewTop + currentWindow.height();
		var elemTop = mainCartElm.offset().top;
		var elemBottom = elemTop + mainCartElm.height();
		var notInView= (elemBottom<=docViewTop || elemTop>=docViewBottom);

		/*fade in minicart if needed**/
		if(notInView && miniCartElm.is(':hidden')){
			/*add padding if set **/
			if(typeof elmToPad !=='undefined'){
				elmToPad.animate({'padding-top': '+='+addElmPaddingTop+'px'},250);
			}
			miniCartElm.fadeIn(250);
		}
		
		if(!notInView && miniCartElm.is(':visible')){
			/*reset padding if required **/
			if(typeof elmToPad !=='undefined'){
				elmToPad.animate({'padding-top': '-='+addElmPaddingTop+'px'},250);
			}
			miniCartElm.fadeOut(250);		
		}	
	};
	/***********************************************
	*
	*	[show/scroll to cart from minicart viewcart button]
	*
	***********************************************/
	$(document).on('click', '.ogconnect-totals-viewcart', function(e){	
		var mainCartElm=$(".ogconnect-cart");
		if(mainCartElm.length>0){
			var miniCartElm=$("#ogconnect-mini-cart");
			var miniCartElmHeight=miniCartElm.outerHeight()
			var elmBottom = miniCartElm.position().top + miniCartElmHeight;
			/*add 10 px for prettyness*/
			var srollToPosition=mainCartElm.offset().top-(elmBottom+10)			
			$('html, body').animate({
				/*scroll it to bottom of minicart element +10. rounded in case outerHeight throws fractions*/
    			scrollTop: Math.round(srollToPosition)
			}, 100);
		}
	});

});