<?php
/*
	OGCONNECT : css for grid based template
	
	this css gets loaded after and in conjunction with the responsive.css
	overriding declarations needed for grid layout
	
	if you want to change it directly , copy it to your theme's directory to not loose any chengs on updates
	
	alternatively, either create a ogconnect-custom.css in your theme's directory and override declarations as required
	or - if your theme supports it - add your custom css wherever appropriate
*/
/**get / set headers, grid variables etc **/
require('../inc/frontend.require.grid-css.inc.php');
?>
/****************************************************************************************
*
*
*
*	[menu items loop - as grid - layout]
*
*
*
****************************************************************************************/
/*******************
	[grid sections/grouping]
*******************/
.ogconnect-grid-section{border:none;clear: both;padding: 0px !important;margin: 0px !important;margin-bottom: 2px !important;display: -webkit-flex;display: -ms-flexbox;display: flex; }
.ogconnect-grid-section:before,.ogconnect-grid-section:after { content:""; display:table; }
.ogconnect-grid-section:after { clear:both;}
.ogconnect-grid-section { zoom:1; /* For IE 6/7 */ }
/*******************
	[menu item (article)]
*******************/
article.ogconnect-article, article.ogconnect-article-clear{	display: block;	float:left;	margin: 1% 0 1% <?php echo $margin ?>%;	padding:0 !important;	width: <?php echo $colwidth ?>% ;flex:1; border:1px dotted #CECECE;	border-radius: 5px;}
article.ogconnect-article:first-child{margin-left: 0 !important; }
/*******************
	[dummies]
*******************/
article.ogconnect-article-clear{border-color:transparent !important; background:transparent !important;}
/*******************
	[menu item (article) inner - wraps to actual content]
*******************/
.ogconnect-article-inner{padding:2px;}
/*******************
	[menu item title]
*******************/
h2.ogconnect-article-title{padding-bottom:0;margin:0;text-align:center}
/*******************
	[thumbnails]
*******************/
.ogconnect-article-img{text-align:center;float:none}
.ogconnect-article-img .ogconnect-article-img-thumb{padding:5px;margin:0 auto !important;border:1px dotted #CECECE;width:auto;max-width:none !important}
.ogconnect-article-img .ogconnect-article-img-placeholder{padding:5px;margin:0 auto !important;border:1px dotted #CECECE;width:75px;height:75px;background:url('img/no_image.png') center center no-repeat;}
/*******************
	[additives]
*******************/
.ogconnect-article-additives-wrap{margin-left:5px}
.ogconnect-article-additives{font-size:60%;margin:0;font-weight:normal}
.ogconnect-article-additives>span{cursor:pointer}
.ogconnect-article-additives:before{content:'*'}
/*******************
	[prices and labels]
*******************/
/*prices wrap*/
.ogconnect-article-tiers{position:relative;margin:0 auto;overflow:auto;text-align:center;float:none}
/*ul prices and currency symbol*/
.ogconnect-article-tiers>ul{list-style-type:none; padding:0px; margin: 0px auto; display:inline-block;}
.ogconnect-article-tiers>ul>li{margin:0 !important;line-height:normal;display:table-cell;}
/*prices list*/
.ogconnect-article-prices>ul{list-style-type:none !important; padding:0px; margin: 0px auto; display:inline-block;}
.ogconnect-article-prices>ul>li{float:left;margin:0!important;line-height:normal;display:inline-block;}
/*prices*/
.ogconnect-article-price{text-align:center;padding:3px;font-size:120%;}
.ogconnect-article-price:hover{cursor:pointer;}
.ogconnect-article-price>span{margin:0 !important;padding:0;display:inline !important;}
.ogconnect-article-price>span:hover{text-decoration:underline}
.ogconnect-article-price-lbl{font-size:60%;text-align:center;white-space: nowrap;}
.ogconnect-article-price-lbl:hover{text-decoration:underline}
.ogconnect-article-price-lbl:after{content: url('img/cart-black-12-12.png');position: relative;top: 2px;margin-left: 2px;}
/*large currency symbol*/
.ogconnect-article-price-currency{font-size:160%;padding:0 10px !important;text-align:center;vertical-align:middle}
/*******************
	[text/content]
*******************/
.ogconnect-article-info{font-size:80%;text-align:justify}
.ogconnect-article-info p{margin:0}
.ogconnect-article-info h2,.ogconnect-article-info h3{display:inline;display:inline-block;padding-bottom:0;margin:0}
/***************************************
*
*	[media query]
*	GO FULL WIDTH BELOW xx PIXELS
*
***************************************/
@media only screen and (max-width: <?php echo"".$fullwidth."" ?>px) {
	.ogconnect-grid-section{display:block;}
	.ogconnect-article {margin: 1% auto !important; width: 100%!important;}
}