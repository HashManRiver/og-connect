<?php if ( ! defined( 'ABSPATH' ) ) exit;/*Exit if accessed directly*/ ?>
<?php
	if(!isset($k)){
		$val=array('date'=>'','open'=>'','close'=>'');
	}else{
		$val=array('date'=>date("d M Y",strtotime($options['date'][$k])),'open'=>$options['open'][$k],'close'=>$options['close'][$k]);
	}
	$str='';
	$str.="<span class='ogconnect_option'>";
	$str.="<input name='".$this->pluginSlug."[".$field."][date][]' size='10' type='text' class='ogconnect-date-select' value='".$val['date']."' />";
	$str.="".__('open from', $this->pluginLocale).":";
	$str.="<input name='".$this->pluginSlug."[".$field."][open][]' size='3' type='text' class='ogconnect-time-select' value='".$val['open']."' />";
	$str.="".__('to', $this->pluginLocale).":";
	$str.="<input name='".$this->pluginSlug."[".$field."][close][]' size='3' type='text' class='ogconnect-time-select' value='".$val['close']."' />";
	$str.="<a href='#' class='ogconnect-delete ".$field." button' title='".__('delete', $this->pluginLocale)."'> [X] </a>";
	$str.="</span>";
?>